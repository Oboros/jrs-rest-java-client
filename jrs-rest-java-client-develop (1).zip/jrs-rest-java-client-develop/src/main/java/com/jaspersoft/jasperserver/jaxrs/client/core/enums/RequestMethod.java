package com.jaspersoft.jasperserver.jaxrs.client.core.enums;

/**
 * @author Tetiana Iefimenko
 */
public enum RequestMethod {
    GET,
    DELETE,
    POST,
    PUT;
}
